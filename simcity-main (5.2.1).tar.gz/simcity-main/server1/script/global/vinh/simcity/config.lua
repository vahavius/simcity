fightChance = 8000 -- 1/8000 co hoi chuyen sang chien dau
joinFightChance = 3000 -- 1/3000 co hoi tham gia danh nhau khi di ngang qua dam danh nhau
attackPlayerChance = 2000 -- 1/3000 co hoi danh nguoi neu den gan nguoi choi dang chien dau



fightPlayerRadius = 8	-- tam quet nguoi choi chung quanh va tan cong
attackNpcRadius = 8	-- tam quet NPC chung quanh va tan cong
fightScanRadius = 8	-- tam quet dam danh nhau chung quanh de tham gia


talkChance = 200	-- 1/200 co hoi noi chuyen

tg_danhnhau = {	-- khoang thoi gian danh nhau  (45-120giay)
	minTs = 45,
	maxTs = 120
}

tg_nghingoi = {	-- nghi ngoi, khong danh nhau lai trong vong thoi gian nay
	minTs = 30,
	maxTs = 60	
}


tongkim_tudongThemNV = 0
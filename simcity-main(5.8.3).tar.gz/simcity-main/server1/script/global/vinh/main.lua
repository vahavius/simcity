
Include("\\script\\global\\vinh\\simcity\\main.lua")
Include("\\script\\misc\\eventsys\\eventsys.lua")

function add_npc_vinh()
end

function simcity_addNpcs()
	-- SimCity: them Trieu Man o 7 thanh
	SimCityMainThanhThi:addNpcs()
	
	-- KeoXe: them VoKy o TuongDuong
	add_dialognpc({ 
		{103,78,1619,3251,"\\script\\global\\vinh\\simcity\\controllers\\keoxe.lua","V� K�"}, 
	})

	-- VatNuoi: them VatNuoi o TuongDuong
	SimCityVatNuoi:addNpcs()

	-- Event sys when user enter/leave map
	for id, map in SimCityMap do
		EventSys:GetType("EnterMap"):Reg(id, SimCityMainThanhThi.onPlayerEnterMap, SimCityMainThanhThi)
		EventSys:GetType("LeaveMap"):Reg(id, SimCityMainThanhThi.onPlayerExitMap, SimCityMainThanhThi)
		EventSys:GetType("EnterMap"):Reg(id, SimCityVatNuoi.onPlayerEnterMap, SimCityVatNuoi)		
	end
	

end

function simcity_clearTongKim()
	SimCityChienTranh:removeAll()
end
balanghuyen_nam ={

}

balanghuyen_tay = {
	
}

balanghuyen_bac = {
	
}





map_balanghuyen = {
	worldId = 53, 
	name = "L�m An", 
	walkAreas = {
		lamAn_cungChinh, 
		lamAn_cungPhu1, 
		lamAn_cungPhu2,
		lamAn_cungPhu3,
		lamAn_cungPhu4
	}, 
	decoration = {},
	chientranh = {}
}
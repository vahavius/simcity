Include("\\script\\global\\vinh\\simcity\\libs\\common.lua")
Include("\\script\\global\\vinh\\simcity\\libs\\walk.lua")

Include("\\script\\global\\vinh\\simcity\\head.lua")



function main()
	return SimCityKeoXe:mainMenu()
end

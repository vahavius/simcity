
Include("\\script\\global\\vinh\\simcity\\data\\mbienkinh.lua")
Include("\\script\\global\\vinh\\simcity\\data\\mdaily.lua")
Include("\\script\\global\\vinh\\simcity\\data\\mlaman.lua")
Include("\\script\\global\\vinh\\simcity\\data\\mtuongduong.lua")
Include("\\script\\global\\vinh\\simcity\\data\\mphuongtuong.lua")
Include("\\script\\global\\vinh\\simcity\\data\\mtongkim_nguyensoai.lua")
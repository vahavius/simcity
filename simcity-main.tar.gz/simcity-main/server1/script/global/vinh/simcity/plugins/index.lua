
Include("\\script\\global\\vinh\\simcity\\plugins\\pngoaitrang.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pworld.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pchat.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pnpcinfo.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pname.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pchientranh.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\ptongkim.lua")
Include("\\script\\global\\vinh\\simcity\\plugins\\pkeoxe.lua")
